var ROWS = 10;
var COLS = 10;

function go() {
	var out = document.getElementsByClassName("funky")[0];
	var table = document.createElement("table");
	table.border = 1;
	for (var i=0; i < ROWS; i += 1) {
		var row = document.createElement("tr");
		if (i == 2) {
			row.Fontweight = "bold";
		}
		for (var j=0; j < COLS; j += 1) {
			var col = document.createElement("td");
			col.innerHTML = i + " " +  j;
			if (j%2 == 0) {
				col.style.color = "purple";
			}
			row.appendChild(col)
		}
		table.appendChild(row);
	}
  out.appendChild(table);
}
onload = go
