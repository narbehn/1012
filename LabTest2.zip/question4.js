function go()
{
  var input = document.getElementById("input");
  var output = document.getElementById("output");
  output.innerText = input.innerText.replace(/ |x/g, '');
}
onload = go;
