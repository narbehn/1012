function myfunc(a, b, c) {
	return {"first" : oddOnly(a),
          "2nd" : noNums(b),
          "three" : removeFirst(c)
        };
}

function oddOnly(n){
  arr =[];
  for(var i = 0; i < n.length; i++){
    if((Math.abs(n[i]) % 2) == 1){
      arr.push(n[i]);
    }
  }
  return arr;
}

function noNums(str){
  var result = str.replace(/\d/g, '');
  return result;
}

function removeFirst(s){
     return s.substring(1);
}

function validate() {
	var out = document.getElementById("output");

	test = myfunc([1,2,3,4], "abc123def456", "hello")
	if (JSON.stringify(test["first"]) == JSON.stringify([1,3]) && test["2nd"] == "abcdef" && test["three"] == "ello") {
		out.innerHTML += "Passed test 1 " + test["first"] + " " + test["2nd"] + " " + test["three"] + "<br>";
	} else {
		out.innerHTML += "!!!!! Failed test 1 " + test["first"] + " " + test["2nd"] + " " + test["three"] + "<br>";
	}

	test = myfunc([10,5,6,4,1], "...1--def46", "test")
	if (JSON.stringify(test["first"]) == JSON.stringify([5,1]) && test["2nd"] == "...--def" && test["three"] == "est") {
		out.innerHTML += "Passed test 2 " + test["first"] + " " + test["2nd"] + " " + test["three"] + "<br>";
	} else {
		out.innerHTML += "!!!!! Failed test 2 " + test["first"] + " " + test["2nd"] + " " + test["three"] + "<br>";
	}

	test1 = myfunc([-1,12,-3], "aeligha", "why")
	if (JSON.stringify(test1["first"]) == JSON.stringify([-1,-3]) && test1["2nd"] == "aeligha" && test1["three"] == "hy") {
		out.innerHTML += "Passed test 3 " + test1["first"] + " " + test1["2nd"] + " " + test1["three"] + "<br>";
	} else {
		out.innerHTML += "!!!!! Failed test 3 " + test1["first"] + " " + test1["2nd"] + " " + test1["three"] + "<br>";
	}
}

window.onload = validate
